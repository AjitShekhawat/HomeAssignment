/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SourceCode;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ajit Singh
 */
public class CustomerComment extends HttpServlet {
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter(); 
        
        try 
          
        {
           
            String comment=request.getParameter("cmnt");
            
          HttpSession sess=request.getSession(false);
          String Email=(String)sess.getAttribute("Email");
         
           PreparedStatement pst,pst1;
              
                Class.forName("com.mysql.jdbc.Driver");
	        Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/zipboard","root","ajit");
                
                
               pst=con.prepareStatement("insert into customerComment(Email,comment,Time,date)values (?,?,CURTIME(),CURDATE())");
               pst.setString(1,Email); 
               pst.setString(2,comment);
                
                int status=pst.executeUpdate();
                if(status>0)
                {
                     request.setAttribute("msg","Your Comment Post Successfull");
                   pst1=con.prepareStatement("select * from customerComment ");
                  
                     ResultSet rs=pst1.executeQuery();
               
                    rs.next();
                 
                    ServletContext sc = getServletContext();
                    sc.getRequestDispatcher("/Discussion_info.jsp").forward(request, response);
                    
                }
               else
                {
                    request.setAttribute("msgfailed","Your Comment Post Successfull");
                    out.println("Failed to Post Your Comment Try Again !!! ");
                }
                
        }
        
        catch(Exception e)
        {
            out.println("Exception"+e);
        }
    }

}