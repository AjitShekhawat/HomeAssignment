/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SourceCode;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ajit Singh
 */
public class CustomerRegistration extends HttpServlet {

     
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter(); 
        
        try 
          
        {
           
            String first_name=request.getParameter("first_name");
            String last_name=request.getParameter("last_name");
            String DOB=request.getParameter("DOB");
            String gender=request.getParameter("gender");
               String mobile_no=request.getParameter("mobile_no");
               String email=request.getParameter("email_id");
               String district=request.getParameter("district");
               String state=request.getParameter("state");
               String pass=request.getParameter("pass");
                
                PreparedStatement pst,pst2;
              
                Class.forName("com.mysql.jdbc.Driver");
	        Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/zipboard","root","ajit");
                
                
               pst=con.prepareStatement("insert into customer_info(Email,F_name,L_name,Dob,Mob_no,District,State,Password,Gender)values (?,?,?,?,?,?,?,?,?)");
               pst.setString(1,email); 
               pst.setString(2,first_name);
                pst.setString(3,last_name);
                pst.setString(4,DOB);
                pst.setString(5,mobile_no);
                pst.setString(6,district);
                pst.setString(7,state);
                pst.setString(8,pass);
                pst.setString(9,gender);
               
                int status=pst.executeUpdate();
                if(status>0)
                {
                   out.println("ssss"+email);
                     request.setAttribute("msg","Registration Successfull");
                   pst2=con.prepareStatement("select * from customer_info where EMAIL=?");
                   pst2.setString(1,email);
                     ResultSet rs=pst2.executeQuery();
               
                    rs.next();
                 String emailid=rs.getString("email");
                   request.setAttribute("id",emailid);
                    ServletContext sc = getServletContext();
                    sc.getRequestDispatcher("/Home.jsp").forward(request, response);
                    
                }
               else
                {
                    out.println("Registration Failed");
                }
                
        }
        
        
        catch(Exception e)
        {
            out.println("Exception"+e);
        }
    }

}
