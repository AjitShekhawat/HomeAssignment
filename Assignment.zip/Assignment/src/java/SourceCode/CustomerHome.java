/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SourceCode;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ajit Singh
 */
public class CustomerHome extends HttpServlet {

   String eid;
      
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter(); 
        
       try 
          
        {
            eid=request.getParameter("eid");
            String pwd=request.getParameter("password");
            ResultSet rs ;
                PreparedStatement pst;
                Class.forName("com.mysql.jdbc.Driver");
	        Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/zipboard","root","ajit");
                pst=con.prepareStatement("select * from customer_info where email=?");
                pst.setString(1,eid);
                rs =pst.executeQuery();
                rs.next();
                 
                String password=rs.getString("password");
                String f_name=rs.getString("f_name");
                String l_name=rs.getString("l_name");
                String Name=f_name+" "+l_name;
                String Email=rs.getString("email");
               HttpSession sess=request.getSession(true);
             if(password.equals(pwd))
             {
                 sess.setAttribute("Name",Name);
                 sess.setAttribute("Email",Email);
             ServletContext sc = getServletContext();
             sc.getRequestDispatcher("/Customer_Home.jsp").forward(request, response);
             }
        
             else
             {
             request.setAttribute("errmsg","Authentication Failed !!!");
             ServletContext sc = getServletContext();
             sc.getRequestDispatcher("/Home.jsp").forward(request, response);
             }
        }
        
        catch(Exception e)
        {
            out.println("Exception"+e);
        }
    }

}